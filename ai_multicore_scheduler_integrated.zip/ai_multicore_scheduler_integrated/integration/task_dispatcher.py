class TaskDispatcher:
    def __init__(self, cpu_manager, dqn_adapter):
        self.cpu_manager = cpu_manager
        self.dqn_adapter = dqn_adapter
        self.seen_ids = set()

    def submit(self, task, state=None, fallback_core=None):
        if task.task_id in self.seen_ids:
            raise ValueError(f"Duplicate task_id: {task.task_id}")
        core = self.dqn_adapter.select_core(
            state, {"task_id":task.task_id, "runtime_ms":task.total_runtime_ms,
                    "cpu_usage":task.cpu_usage, "nice":task.nice,
                    "waiting_time_ms":task.waiting_time_ms},
            fallback_core
        )
        self.cpu_manager.queue_for(core).enqueue(task)
        self.seen_ids.add(task.task_id)
        return core
