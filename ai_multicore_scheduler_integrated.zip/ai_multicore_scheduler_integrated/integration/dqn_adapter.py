class DQNAdapter:
    """Connect the teammate's inference function later; it should return core 0..15."""
    def __init__(self, policy_callable=None, num_cores=16):
        self.policy_callable = policy_callable
        self.num_cores = num_cores

    def select_core(self, state=None, task_features=None, fallback_core=None):
        if self.policy_callable is None:
            if fallback_core is None:
                raise RuntimeError("DQN not connected; provide fallback_core for local testing")
            core = fallback_core
        else:
            core = self.policy_callable(state, task_features)
        if not isinstance(core, int) or not 0 <= core < self.num_cores:
            raise ValueError(f"Invalid DQN core action: {core}")
        return core
