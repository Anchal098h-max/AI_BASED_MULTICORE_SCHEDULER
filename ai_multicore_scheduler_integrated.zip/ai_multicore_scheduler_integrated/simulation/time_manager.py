class TimeManager:
    def __init__(self, tick_ms=1.0):
        if tick_ms <= 0:
            raise ValueError("tick_ms must be positive")
        self.tick_ms = float(tick_ms)
        self.now_ms = 0.0

    def advance(self):
        self.now_ms += self.tick_ms
