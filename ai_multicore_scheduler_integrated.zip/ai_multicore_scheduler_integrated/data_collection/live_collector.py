"""Live Linux feature collector matching the team's 35-feature LSTM input."""
import re
from pathlib import Path
import numpy as np
import psutil

NUM_CORES = 16
POLL_SECONDS = 1.0
QUEUE_FILES = (Path('/sys/kernel/debug/sched/debug'), Path('/proc/sched_debug'))


class LiveFeatureCollector:
    def __init__(self, num_cores=NUM_CORES, poll_seconds=POLL_SECONDS):
        self.num_cores = num_cores
        self.poll_seconds = poll_seconds
        detected = psutil.cpu_count(logical=True)
        if detected != num_cores:
            raise RuntimeError(
                f"This trained model requires {num_cores} logical CPUs; this machine reports {detected}. "
                "Run full live inference on a teammate's 16-logical-CPU machine."
            )

    def read_per_cpu_queues(self):
        sched_file = next((p for p in QUEUE_FILES if p.is_file()), None)
        if sched_file is None:
            raise RuntimeError('Scheduler debug file unavailable; check debugfs mount/access.')
        try:
            lines = sched_file.read_text(errors='replace').splitlines()
        except OSError as exc:
            raise RuntimeError(
                f'Cannot read {sched_file}. Run the live pipeline with suitable permission '
                '(for example, sudo using the venv Python executable).'
            ) from exc

        queues, current_cpu = {}, None
        for line in lines:
            cpu_match = re.match(r'\s*cpu#(\d+)', line)
            if cpu_match:
                current_cpu = int(cpu_match.group(1))
                continue
            count_match = re.search(r'\bnr_running\s*:\s*(\d+)', line)
            if count_match and current_cpu is not None and current_cpu not in queues:
                queues[current_cpu] = int(count_match.group(1))
        missing = [i for i in range(self.num_cores) if i not in queues]
        if missing:
            raise RuntimeError(f'Missing scheduler queue readings for CPUs: {missing}')
        return [queues[i] for i in range(self.num_cores)]

    def collect_features(self):
        cpu_util = psutil.cpu_percent(interval=self.poll_seconds, percpu=True)
        if len(cpu_util) != self.num_cores:
            raise RuntimeError(f'Expected {self.num_cores} CPU readings, got {len(cpu_util)}')
        process_count = 0
        running_processes = 0
        for proc in psutil.process_iter(['status']):
            try:
                process_count += 1
                if proc.info.get('status') == psutil.STATUS_RUNNING:
                    running_processes += 1
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        queues = self.read_per_cpu_queues()
        overall_cpu = float(np.mean(cpu_util))
        features = np.asarray(
            list(cpu_util) + queues + [process_count, running_processes, overall_cpu],
            dtype=np.float32,
        )
        if features.shape != (35,) or not np.isfinite(features).all():
            raise RuntimeError('Collected feature vector is not 35 finite values')
        return features
