from core.task import Task
from core.cpu_manager import CPUManager
from core.cfs_scheduler import CFSScheduler, CFSConfig
from core.scheduler_engine import SchedulerEngine
from integration.dqn_adapter import DQNAdapter
from integration.task_dispatcher import TaskDispatcher
from config import *

def main():
    cpus = CPUManager(NUM_CORES)
    cfs = CFSScheduler(CFSConfig(SCHEDULING_PERIOD_MS, MIN_GRANULARITY_MS,
                                 PREEMPT_GRANULARITY_VRUNTIME_MS))
    # fallback_core is for local testing only; replace with DQN inference later.
    dispatcher = TaskDispatcher(cpus, DQNAdapter())
    tasks = [
        Task(101, 12, nice=0),
        Task(102, 18, priority="High"),
        Task(103, 9, priority="Low"),
        Task(104, 15, nice=2),
    ]
    for task, core in zip(tasks, [0, 0, 0, 1]):
        print(f"Task {task.task_id} assigned to CPU {dispatcher.submit(task, fallback_core=core)}")

    engine = SchedulerEngine(cpus, cfs, TICK_MS)
    result = engine.run()
    print("\nSimulation time:", result["simulation_time_ms"], "ms")
    print("Metrics:", result["metrics"])
    for cpu in result["cores"]:
        print(cpu["core_id"], "running:", cpu["running_task_id"],
              "queue:", cpu["queue_length"])

if __name__ == "__main__":
    main()
