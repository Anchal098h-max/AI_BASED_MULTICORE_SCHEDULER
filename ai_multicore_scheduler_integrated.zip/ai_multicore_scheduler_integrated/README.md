# 16-Core CFS-Inspired Scheduler Simulation

## Run
From this folder:
```bash
python main.py
python -m unittest discover -s tests -v
```

## What it models
- 16 independent simulated per-core run queues.
- DQN adapter accepting a core action from 0 to 15.
- Nice-to-weight mapping, vruntime accounting, minimum-vruntime task selection.
- Discrete simulation ticks, weighted ideal-slice estimate, same-core re-enqueue.
- Basic waiting, turnaround and throughput metrics.

## Important limitations
This is a user-space educational simulation, not a Linux kernel scheduler.
It does not control real CPU execution, reproduce all kernel CFS details, or implement EEVDF.
The queue uses a Python dictionary and O(n) selection rather than Linux's red-black tree.
Scheduling period, granularity and preemption settings are simulator parameters.
Priority labels map to representative nice values only when nice is not supplied.

## DQN integration
The model may return only the selected core. The task ID remains attached to the Task object.
Connect Person 2's inference callable to `DQNAdapter(policy_callable=...)` after agreeing on
the exact state and feature interface. `fallback_core` is only for local tests.
