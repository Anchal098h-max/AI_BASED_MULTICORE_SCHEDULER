NUM_CORES = 16
TICK_MS = 1.0
# Educational simulation parameters, not copied Linux kernel tunables.
SCHEDULING_PERIOD_MS = 24.0
MIN_GRANULARITY_MS = 3.0
PREEMPT_GRANULARITY_VRUNTIME_MS = 2.0
