"""Offline model integration smoke test; does not require a 16-core host or debugfs."""
import numpy as np
from ai_model.runtime import AIModelRuntime


def main():
    runtime = AIModelRuntime(device='cpu')
    # Synthetic 20x35 sample shaped exactly like the trained LSTM input.
    # This verifies checkpoint/scaler loading and LSTM->DQN tensor compatibility,
    # not prediction quality on real machine data.
    history = np.zeros((20, 35), dtype=np.float32)
    history[:, 0:16] = 20.0
    history[:, 16:32] = 1.0
    history[:, 32] = 100.0
    history[:, 33] = 5.0
    history[:, 34] = 20.0
    task = {
        'cpu_usage': 25.0,
        'runtime_ms': 5000.0,
        'nice': 0,
        'waiting_time_ms': 10.0,
    }
    state, prediction = runtime.build_state(history, task)
    core = runtime.select_core(history, task)
    print('LSTM prediction shape:', prediction.shape)
    print('DQN state shape:', state.shape)
    print('Selected simulated core:', core)
    print('Offline model integration smoke test: PASS')


if __name__ == '__main__':
    main()
