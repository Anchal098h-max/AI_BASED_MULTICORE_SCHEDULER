"""One-shot integration demo: live OS features -> LSTM -> DQN -> simulated CFS queues.

The sample tasks below are simulator inputs, not actual Linux processes. Replace them
with Person 4's task-provider/API once that interface is agreed.
"""
from collections import deque
import numpy as np

from ai_model.runtime import AIModelRuntime
from data_collection.live_collector import LiveFeatureCollector
from core.task import Task
from core.cpu_manager import CPUManager
from core.cfs_scheduler import CFSScheduler, CFSConfig
from core.scheduler_engine import SchedulerEngine
from integration.dqn_adapter import DQNAdapter
from integration.task_dispatcher import TaskDispatcher
from config import NUM_CORES, TICK_MS, SCHEDULING_PERIOD_MS, MIN_GRANULARITY_MS, PREEMPT_GRANULARITY_VRUNTIME_MS


def main():
    collector = LiveFeatureCollector(num_cores=NUM_CORES)
    print('Collecting 20 live samples (about 20 seconds) for LSTM...')
    history = deque(maxlen=20)
    for sample_no in range(20):
        history.append(collector.collect_features())
        print(f'Collected sample {sample_no + 1}/20')
    feature_history = np.stack(history)

    ai = AIModelRuntime()
    cpu_manager = CPUManager(NUM_CORES)
    cfs = CFSScheduler(CFSConfig(
        SCHEDULING_PERIOD_MS, MIN_GRANULARITY_MS, PREEMPT_GRANULARITY_VRUNTIME_MS
    ))
    dispatcher = TaskDispatcher(cpu_manager, DQNAdapter(policy_callable=ai.select_core))

    # Temporary sample tasks to verify integration. These are not OS PIDs.
    tasks = [
        Task(9001, total_runtime_ms=2500, nice=0, cpu_usage=18.0),
        Task(9002, total_runtime_ms=5000, nice=5, cpu_usage=42.0),
        Task(9003, total_runtime_ms=3500, nice=-3, cpu_usage=27.0),
    ]
    for task in tasks:
        selected_core = dispatcher.submit(task, state=feature_history)
        print(f'Task {task.task_id} -> DQN selected CPU {selected_core}')

    engine = SchedulerEngine(cpu_manager, cfs, TICK_MS)
    result = engine.run()
    print('\nSimulation time:', result['simulation_time_ms'], 'ms')
    print('Metrics:', result['metrics'])
    for core in result['cores']:
        print(f"CPU {core['core_id']}: running={core['running_task_id']}, queue={core['queue_length']}")


if __name__ == '__main__':
    main()
