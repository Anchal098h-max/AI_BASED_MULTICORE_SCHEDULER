"""Inference wrapper for the team's trained 16-core LSTM and DQN models."""
from pathlib import Path
import numpy as np
import joblib
import torch
import torch.nn as nn

NUM_CORES = 16
LSTM_FEATURES = 35
DQN_STATE_DIM = 52


class CpuUtilizationLSTM(nn.Module):
    def __init__(self, input_size=35, hidden1=128, hidden2=64, output_size=16, dropout=0):
        super().__init__()
        self.lstm1 = nn.LSTM(input_size, hidden1, batch_first=True)
        self.dropout1 = nn.Dropout(dropout)
        self.lstm2 = nn.LSTM(hidden1, hidden2, batch_first=True)
        self.dropout2 = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden2, output_size)

    def forward(self, x):
        out, _ = self.lstm1(x)
        out = self.dropout1(out)
        out, _ = self.lstm2(out)
        out = self.dropout2(out)
        return self.fc(out[:, -1, :])


class DQNetwork(nn.Module):
    def __init__(self, state_dim=52, action_dim=16):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(state_dim, 128), nn.ReLU(),
            nn.Linear(128, 128), nn.ReLU(),
            nn.Linear(128, action_dim),
        )

    def forward(self, state):
        return self.network(state)


class AIModelRuntime:
    """Loads the supplied checkpoints and maps a 20x35 feature window to a core."""
    def __init__(self, model_root=None, device=None):
        project_root = Path(__file__).resolve().parents[1]
        model_root = Path(model_root) if model_root else project_root / "models"
        lstm_dir = model_root / "LSTM_training"
        dqn_dir = model_root / "DQN_training"
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))

        x_scaler_path = lstm_dir / "cpu_feature_scaler.pkl"
        y_scaler_path = lstm_dir / "cpu_target_scaler.pkl"
        lstm_path = lstm_dir / "cpu_lstm_model.pth"
        dqn_path = dqn_dir / "dqn_schedular_fnf.pth"
        for path in (x_scaler_path, y_scaler_path, lstm_path, dqn_path):
            if not path.is_file():
                raise FileNotFoundError(f"Required model artifact missing: {path}")

        self.x_scaler = joblib.load(x_scaler_path)
        self.y_scaler = joblib.load(y_scaler_path)
        if getattr(self.x_scaler, "n_features_in_", None) != LSTM_FEATURES:
            raise ValueError("LSTM feature scaler must expect 35 features")
        if getattr(self.y_scaler, "n_features_in_", None) != NUM_CORES:
            raise ValueError("LSTM target scaler must expect 16 outputs")

        self.lstm = CpuUtilizationLSTM().to(self.device)
        self.lstm.load_state_dict(torch.load(lstm_path, map_location=self.device, weights_only=True))
        self.lstm.eval()

        self.dqn = DQNetwork().to(self.device)
        self.dqn.load_state_dict(torch.load(dqn_path, map_location=self.device, weights_only=True))
        self.dqn.eval()

    @staticmethod
    def encode_task_features(task_cpu_usage, task_runtime_seconds, task_priority_nice, task_wait_time_ms):
        # This normalization is copied from the team's DQN model_load notebook.
        return np.asarray([
            np.clip(float(task_cpu_usage) / 100.0, 0.0, 1.0),
            np.clip(float(task_runtime_seconds) / 60.0, 0.0, 1.0),
            np.clip((float(task_priority_nice) + 20.0) / 39.0, 0.0, 1.0),
            np.clip(float(task_wait_time_ms) / 1000.0, 0.0, 1.0),
        ], dtype=np.float32)

    def build_state(self, feature_history, task_features):
        history = np.asarray(feature_history, dtype=np.float32)
        if history.shape != (20, LSTM_FEATURES):
            raise ValueError(f"LSTM history must have shape (20, 35), got {history.shape}")
        if not np.isfinite(history).all():
            raise ValueError("LSTM history contains NaN or infinite values")

        scaled = self.x_scaler.transform(history)
        x = torch.as_tensor(scaled[np.newaxis, :, :], dtype=torch.float32, device=self.device)
        with torch.no_grad():
            prediction_scaled = self.lstm(x).cpu().numpy()
        predicted_utilization = self.y_scaler.inverse_transform(prediction_scaled)[0].astype(np.float32)

        # Collector feature order: cpu[0:16], queues[16:32], then 3 system metrics.
        current_utilization = history[-1, 0:16]
        queue_lengths = history[-1, 16:32]
        task_vector = self.encode_task_features(
            task_features["cpu_usage"],
            float(task_features["runtime_ms"]) / 1000.0,
            task_features["nice"],
            task_features.get("waiting_time_ms", 0.0),
        )
        state = np.concatenate([
            predicted_utilization, current_utilization, queue_lengths, task_vector
        ]).astype(np.float32)
        if state.shape != (DQN_STATE_DIM,) or not np.isfinite(state).all():
            raise ValueError("Constructed DQN state must contain 52 finite values")
        return state, predicted_utilization

    def select_core(self, feature_history, task_features):
        state, _ = self.build_state(feature_history, task_features)
        tensor = torch.as_tensor(state, dtype=torch.float32, device=self.device).reshape(1, DQN_STATE_DIM)
        with torch.no_grad():
            q_values = self.dqn(tensor)
            return int(q_values.argmax(dim=1).item())
