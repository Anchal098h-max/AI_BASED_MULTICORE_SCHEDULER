# AI Multicore Scheduler — first integration build

This build connects the supplied LSTM and DQN checkpoints to the Python scheduler.

## Verified model contracts from the supplied notebooks/checkpoints

- LSTM input: 20 time steps x 35 features.
- LSTM feature order: 16 CPU utilization values, 16 per-CPU queue lengths,
  `process_count`, `running_processes`, `overall_cpu_utilization`.
- LSTM output: 16 predicted CPU utilization values.
- DQN input: 52 values = predicted utilization (16) + current utilization (16) +
  queue lengths (16) + encoded task features (4).
- DQN output: 16 Q-values; argmax is the selected logical CPU index 0..15.

## Install on the 16-logical-CPU Linux machine

```bash
python3 -m venv venv
source venv/bin/activate
python -m pip install -r requirements.txt
```

The live collector reads `/sys/kernel/debug/sched/debug`. On systems where this
file is root-readable only, run the program with the virtualenv interpreter under
sudo so the installed packages remain available:

```bash
sudo -E ./venv/bin/python main_live.py
```

If debugfs is not mounted, check:

```bash
mount | grep debugfs
```

Do not use `--break-system-packages`.

## Run

```bash
python main.py
```

runs the scheduler-only demo with fallback core choices.

```bash
sudo -E ./venv/bin/python main_live.py
```

runs the first live integration test. It collects 20 one-second samples, performs
LSTM inference, builds the 52-value DQN state for each sample task, gets a core
index from DQN, enqueues tasks, and runs the CFS-inspired simulator.

**Important:** the three tasks in `main_live.py` are temporary simulator tasks,
not actual OS processes. This Python project simulates scheduling; it does not
change Linux kernel scheduling or move real processes between CPU cores. Replace
the sample task provider with the backend/task source after that API is agreed.

## Hardware constraint

The trained model and live feature collector are configured for exactly 16 logical
CPUs. The user's 12-logical-CPU laptop can run the scheduler-only simulation, but
cannot run this exact live 16-core model path without a separately trained and
validated 12-core model. Use a teammate's 16-logical-CPU Linux machine for full
live inference verification.
