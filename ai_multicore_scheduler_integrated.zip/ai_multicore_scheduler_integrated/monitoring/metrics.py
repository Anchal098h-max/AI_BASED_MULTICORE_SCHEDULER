class Metrics:
    def __init__(self):
        self.completed = []

    def record_completion(self, task):
        self.completed.append(task)

    def summary(self, now_ms):
        if not self.completed:
            return {"completed_count":0, "average_waiting_ms":0.0,
                    "average_turnaround_ms":0.0, "throughput_tasks_per_second":0.0}
        n = len(self.completed)
        turnaround = [t.completion_time_ms - t.arrival_time_ms for t in self.completed]
        waiting = [t.waiting_time_ms for t in self.completed]
        return {"completed_count":n,
                "average_waiting_ms":sum(waiting)/n,
                "average_turnaround_ms":sum(turnaround)/n,
                "throughput_tasks_per_second":n/max(now_ms/1000.0, 1e-12)}
