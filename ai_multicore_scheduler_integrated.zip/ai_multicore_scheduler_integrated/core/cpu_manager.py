from .run_queue import RunQueue

class CPUManager:
    def __init__(self, num_cores=16):
        if num_cores < 1:
            raise ValueError("num_cores must be positive")
        self.num_cores = num_cores
        self.queues = {i:RunQueue(i) for i in range(num_cores)}
        self.current_tasks = {i:None for i in range(num_cores)}

    def validate_core(self, core_id):
        if not isinstance(core_id, int) or not 0 <= core_id < self.num_cores:
            raise ValueError(f"core_id must be in [0, {self.num_cores-1}]")

    def queue_for(self, core_id):
        self.validate_core(core_id)
        return self.queues[core_id]

    def snapshot(self):
        return [{"core_id":i,
                 "running_task_id":self.current_tasks[i].task_id if self.current_tasks[i] else None,
                 "queue_length":self.queues[i].length,
                 "queued_tasks":self.queues[i].snapshot(),
                 "total_runnable_weight":self.queues[i].total_weight}
                for i in range(self.num_cores)]
