from dataclasses import dataclass

@dataclass
class CFSConfig:
    scheduling_period_ms: float = 24.0
    min_granularity_ms: float = 3.0
    preemption_granularity_vruntime_ms: float = 2.0

class CFSScheduler:
    """Classic-CFS-inspired teaching policy, not a Linux kernel implementation."""
    NICE_0_LOAD = 1024

    def __init__(self, config=None):
        self.config = config or CFSConfig()

    def update_vruntime(self, task, executed_ms):
        if executed_ms < 0:
            raise ValueError("executed_ms cannot be negative")
        task.vruntime += executed_ms * self.NICE_0_LOAD / task.weight

    def ideal_slice_ms(self, task, total_runnable_weight):
        if total_runnable_weight <= 0:
            return 0.0
        ideal = self.config.scheduling_period_ms * task.weight / total_runnable_weight
        return max(self.config.min_granularity_ms, ideal)

    def pick_next(self, run_queue):
        return run_queue.pick_next()

    def should_preempt(self, current, candidate):
        return bool(current and candidate and
                    candidate.vruntime + self.config.preemption_granularity_vruntime_ms
                    < current.vruntime)
