from simulation.time_manager import TimeManager
from monitoring.metrics import Metrics

class SchedulerEngine:
    def __init__(self, cpu_manager, cfs, tick_ms=1.0):
        self.cpu_manager = cpu_manager
        self.cfs = cfs
        self.clock = TimeManager(tick_ms)
        self.metrics = Metrics()

    def step(self):
        dt = self.clock.tick_ms

        # READY tasks waiting in queues accrue waiting time.
        for core, queue in self.cpu_manager.queues.items():
            for task in queue.tasks():
                task.waiting_time_ms += dt

        for core in range(self.cpu_manager.num_cores):
            queue = self.cpu_manager.queues[core]
            current = self.cpu_manager.current_tasks[core]

            if current is None:
                current = self.cfs.pick_next(queue)
                if current is not None:
                    queue.dequeue(current.task_id)
                    current.status = "RUNNING"
                    if current.first_run_time_ms is None:
                        current.first_run_time_ms = self.clock.now_ms
                    self.cpu_manager.current_tasks[core] = current

            if current is None:
                continue

            candidate = self.cfs.pick_next(queue)
            if self.cfs.should_preempt(current, candidate):
                current.status = "READY"
                queue.enqueue(current)
                current = self.cfs.pick_next(queue)
                queue.dequeue(current.task_id)
                current.status = "RUNNING"
                if current.first_run_time_ms is None:
                    current.first_run_time_ms = self.clock.now_ms
                self.cpu_manager.current_tasks[core] = current

            used = current.execute(dt)
            self.cfs.update_vruntime(current, used)

            if current.status == "COMPLETED":
                current.completion_time_ms = self.clock.now_ms + used
                self.metrics.record_completion(current)
                self.cpu_manager.current_tasks[core] = None
            else:
                # Slice estimate includes the running task and all queued runnable tasks.
                total_weight = queue.total_weight + current.weight
                slice_ms = self.cfs.ideal_slice_ms(current, total_weight)
                current._slice_used_ms = getattr(current, "_slice_used_ms", 0.0) + used
                if current._slice_used_ms + 1e-12 >= slice_ms:
                    current._slice_used_ms = 0.0
                    current.status = "READY"
                    queue.enqueue(current)
                    self.cpu_manager.current_tasks[core] = None

        self.clock.advance()
        return self.snapshot()

    def run(self, max_ticks=100000):
        for _ in range(max_ticks):
            active = any(q.length for q in self.cpu_manager.queues.values()) or any(
                t is not None for t in self.cpu_manager.current_tasks.values())
            if not active:
                break
            self.step()
        return self.snapshot()

    def snapshot(self):
        return {"simulation_time_ms":self.clock.now_ms,
                "cores":self.cpu_manager.snapshot(),
                "metrics":self.metrics.summary(self.clock.now_ms)}
