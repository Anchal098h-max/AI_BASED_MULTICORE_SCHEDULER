class RunQueue:
    """One simulated CPU's runnable tasks; minimum-vruntime selection is O(n)."""
    def __init__(self, core_id):
        self.core_id = core_id
        self._tasks = {}

    def enqueue(self, task):
        if task.task_id in self._tasks:
            raise ValueError(f"Duplicate task {task.task_id} in queue")
        if task.status == "COMPLETED":
            raise ValueError("Cannot enqueue completed task")
        if task.assigned_core not in (None, self.core_id):
            raise ValueError("Task is assigned to a different core")
        task.assigned_core = self.core_id
        task.status = "READY"
        self._tasks[task.task_id] = task

    def dequeue(self, task_id):
        task = self._tasks.pop(task_id)
        task.assigned_core = None
        return task

    def pick_next(self):
        if not self._tasks:
            return None
        return min(self._tasks.values(),
                   key=lambda t: (t.vruntime, t.arrival_time_ms, t.task_id))

    def tasks(self):
        return list(self._tasks.values())

    @property
    def length(self):
        return len(self._tasks)

    @property
    def total_weight(self):
        return sum(t.weight for t in self._tasks.values())

    def snapshot(self):
        return [{"task_id":t.task_id, "vruntime_ms":round(t.vruntime,3),
                 "remaining_runtime_ms":round(t.remaining_runtime_ms,3),
                 "nice":t.nice, "weight":t.weight, "status":t.status}
                for t in sorted(self._tasks.values(), key=lambda x:(x.vruntime,x.task_id))]
