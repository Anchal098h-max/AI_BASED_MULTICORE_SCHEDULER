from dataclasses import dataclass, field
from typing import Optional

NICE_TO_WEIGHT = {
    -20:88761,-19:71755,-18:56483,-17:46273,-16:36291,-15:29154,
    -14:23254,-13:18705,-12:14949,-11:11916,-10:9548,-9:7620,
    -8:6100,-7:4904,-6:3906,-5:3121,-4:2501,-3:1991,-2:1586,
    -1:1277,0:1024,1:820,2:655,3:526,4:423,5:335,6:272,7:215,
    8:172,9:137,10:110,11:87,12:70,13:56,14:45,15:36,16:29,
    17:23,18:18,19:15
}
PRIORITY_TO_NICE = {"High": -5, "Medium": 0, "Low": 5}

@dataclass
class Task:
    task_id: int
    total_runtime_ms: float
    remaining_runtime_ms: Optional[float] = None
    nice: Optional[int] = None
    priority: str = "Medium"
    arrival_time_ms: float = 0.0
    cpu_usage: float = 0.0
    assigned_core: Optional[int] = None
    status: str = "NEW"
    vruntime: float = 0.0
    executed_time_ms: float = 0.0
    waiting_time_ms: float = 0.0
    first_run_time_ms: Optional[float] = None
    completion_time_ms: Optional[float] = None
    weight: int = field(init=False)

    def __post_init__(self):
        if self.total_runtime_ms <= 0:
            raise ValueError("total_runtime_ms must be positive")
        if self.remaining_runtime_ms is None:
            self.remaining_runtime_ms = float(self.total_runtime_ms)
        if not 0 <= self.remaining_runtime_ms <= self.total_runtime_ms:
            raise ValueError("Invalid remaining runtime")
        if self.nice is None:
            if self.priority not in PRIORITY_TO_NICE:
                raise ValueError("priority must be High, Medium or Low")
            self.nice = PRIORITY_TO_NICE[self.priority]
        if self.nice not in NICE_TO_WEIGHT:
            raise ValueError("nice must be between -20 and +19")
        self.weight = NICE_TO_WEIGHT[self.nice]
        self.priority = "High" if self.nice <= -3 else ("Low" if self.nice >= 3 else "Medium")

    def execute(self, duration_ms):
        if duration_ms < 0:
            raise ValueError("duration cannot be negative")
        used = min(float(duration_ms), self.remaining_runtime_ms)
        self.remaining_runtime_ms -= used
        self.executed_time_ms += used
        self.status = "COMPLETED" if self.remaining_runtime_ms <= 1e-12 else "READY"
        if self.status == "COMPLETED":
            self.remaining_runtime_ms = 0.0
        return used
