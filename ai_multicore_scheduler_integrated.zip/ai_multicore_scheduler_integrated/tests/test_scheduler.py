import unittest
from core.task import Task
from core.run_queue import RunQueue
from core.cpu_manager import CPUManager
from core.cfs_scheduler import CFSScheduler
from core.scheduler_engine import SchedulerEngine
from integration.dqn_adapter import DQNAdapter
from integration.task_dispatcher import TaskDispatcher

class Tests(unittest.TestCase):
    def test_task_exec(self):
        t = Task(1, 10)
        self.assertEqual(t.execute(3), 3)
        self.assertEqual(t.remaining_runtime_ms, 7)

    def test_queue_duplicate(self):
        q = RunQueue(0)
        t = Task(1, 5)
        q.enqueue(t)
        with self.assertRaises(ValueError):
            q.enqueue(t)

    def test_sixteen_cpus(self):
        self.assertEqual(len(CPUManager(16).queues), 16)

    def test_weighted_vruntime(self):
        cfs = CFSScheduler()
        normal, high = Task(1, 10, nice=0), Task(2, 10, nice=-5)
        cfs.update_vruntime(normal, 10)
        cfs.update_vruntime(high, 10)
        self.assertLess(high.vruntime, normal.vruntime)

    def test_end_to_end(self):
        cpus = CPUManager(16)
        dispatcher = TaskDispatcher(cpus, DQNAdapter())
        t = Task(9, 5)
        dispatcher.submit(t, fallback_core=3)
        engine = SchedulerEngine(cpus, CFSScheduler())
        result = engine.run()
        self.assertEqual(result["metrics"]["completed_count"], 1)
        self.assertEqual(t.status, "COMPLETED")

if __name__ == "__main__":
    unittest.main()
